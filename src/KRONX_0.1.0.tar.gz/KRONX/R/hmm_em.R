# ============================================================
# KRONX :: hmm_em.R
# EM fitting loop and volatility-based state ordering.
# ============================================================

#' Fit a Gaussian or Student-t HMM via EM with multiple random restarts.
#'
#' @param x        Numeric vector of observations (log returns).
#' @param K        Integer number of hidden states.
#' @param model    \code{"gaussian"} or \code{"student"}.
#' @param n_starts Number of random restarts.
#' @param max_iter Maximum EM iterations per restart.
#' @param tol      Log-likelihood convergence tolerance.
#' @param nu_grid  Candidate degrees-of-freedom for Student-t grid search.
#' @param verbose  Logical; if \code{TRUE} print iteration progress.
#'
#' @return A list with components:
#'   \describe{
#'     \item{model}{Model type string.}
#'     \item{A}{K x K transition matrix.}
#'     \item{delta}{Length-K initial state probability vector.}
#'     \item{params}{List with \code{mu}, \code{sigma}, and (Student-t) \code{nu}.}
#'     \item{gamma}{T x K posterior state probabilities.}
#'     \item{xi}{(T-1) x K x K posterior joint transition probabilities.}
#'     \item{logLik}{Scalar log-likelihood at convergence.}
#'     \item{n}{Number of observations.}
#'     \item{K}{Number of states.}
#'   }
#' @export
fit_hmm_em <- function(x, K = 3L,
                       model     = c("gaussian", "student"),
                       n_starts  = 5L,
                       max_iter  = 200L,
                       tol       = 1e-6,
                       nu_grid   = c(3:30, 40, 60, 100),
                       verbose   = TRUE) {
  model <- match.arg(model)
  best  <- NULL

  for (s in seq_len(n_starts)) {
    init   <- init_hmm_params(x, K, model)
    A      <- init$A
    delta  <- init$delta
    params <- init$params
    prev_ll <- -Inf

    for (iter in seq_len(max_iter)) {
      # E-step
      logB   <- emission_logdens_matrix(x, params, model)
      fb     <- forward_backward(logB, A, delta)
      ll     <- fb$logLik

      # M-step
      upd    <- update_A_delta(fb)
      A      <- upd$A
      delta  <- upd$delta

      if (model == "gaussian") {
        params <- update_gaussian_params(x, fb$gamma)
      } else {
        params <- update_student_params(x, fb$gamma, params, nu_grid)
      }

      if (verbose) {
        cat(sprintf("model=%s start=%d iter=%d logLik=%.10f\n",
                    model, s, iter, ll))
      }

      if (abs(ll - prev_ll) < tol) break
      prev_ll <- ll
    }

    # Final E-step under converged parameters.
    logB <- emission_logdens_matrix(x, params, model)
    fb   <- forward_backward(logB, A, delta)
    ll   <- fb$logLik

    fit <- list(
      model  = model,
      A      = A,
      delta  = delta,
      params = params,
      gamma  = fb$gamma,
      xi     = fb$xi,
      logLik = ll,
      n      = length(x),
      K      = K
    )

    if (is.null(best) || fit$logLik > best$logLik) best <- fit
  }

  best
}

# Reorder states from lowest to highest volatility.
# Gaussian: ordered by sigma.
# Student-t: ordered by conditional variance = [nu/(nu-2)] * sigma^2.
reorder_fit_by_scale <- function(fit) {
  if (fit$model == "gaussian") {
    ord <- order(fit$params$sigma)
  } else {
    cond_var <- (fit$params$nu / (fit$params$nu - 2)) * fit$params$sigma^2
    ord <- order(cond_var)
  }

  fit$A              <- fit$A[ord, ord, drop = FALSE]
  fit$delta          <- fit$delta[ord]
  fit$gamma          <- fit$gamma[, ord, drop = FALSE]
  fit$params$mu      <- fit$params$mu[ord]
  fit$params$sigma   <- fit$params$sigma[ord]
  if (!is.null(fit$params$nu)) fit$params$nu <- fit$params$nu[ord]
  fit
}

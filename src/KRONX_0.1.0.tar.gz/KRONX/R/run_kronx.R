# ============================================================
# KRONX :: run_kronx.R
# Public entry-point: run the full Clock of Regimes (KRONX)
# pipeline on a CSV file containing a close or Close price
# column.
# ============================================================

#' Run the full Clock of Regimes (KRONX) analysis.
#'
#' Reads a CSV file, extracts the close-price column (case-insensitive match on
#' \code{"close"} or \code{"Close"}), computes log returns, fits Gaussian and
#' Student-t HMMs, builds the KRONX operator chain Q → K → N, and computes a
#' residence-weighted ruin bound.  Results are written to \code{output_dir} and
#' also returned as a named list for further programmatic use.
#'
#' @param file        Path to the CSV file.
#' @param close_col   Name of the close-price column.  The function tries both
#'   the exact name and a case-insensitive match, then falls back to any column
#'   whose name contains \code{"close"}.  Default: \code{"close"}.
#' @param K           Number of hidden states (default \code{3L}).
#' @param n_starts    Number of EM random restarts (default \code{5L}).
#' @param max_iter    Maximum EM iterations per restart (default \code{200L}).
#' @param tol         Log-likelihood convergence tolerance (default \code{1e-6}).
#' @param seed        Random seed for reproducibility (default \code{123L}).
#' @param epsilon_min Minimum baseline Talebian hazard (default \code{0.01}).
#' @param c_hazard    Hazard sensitivity to tail thickness (default \code{0.05}).
#' @param tail_alpha  Left-tail probability for the loss threshold
#'   (default \code{0.01}).
#' @param ruin_horizon Horizon (in observations) for the ruin bound
#'   (default \code{250L}).
#' @param nu_grid     Candidate degrees-of-freedom values for Student-t fitting.
#' @param verbose     Logical; print EM iteration progress (default \code{TRUE}).
#' @param output_dir  Directory for output files.  Created if it does not exist.
#'   Pass \code{NULL} to suppress file output.
#'
#' @return A named list containing:
#' \describe{
#'   \item{close_px}{Numeric vector of raw close prices.}
#'   \item{ret}{Numeric vector of log returns.}
#'   \item{K}{Number of states.}
#'   \item{gauss_fit}{Fitted Gaussian HMM (see \code{\link{fit_hmm_em}}).}
#'   \item{t_fit}{Fitted Student-t HMM.}
#'   \item{A_gauss}{Gaussian transition matrix.}
#'   \item{A_t}{Student-t transition matrix.}
#'   \item{epsilon}{Per-state Talebian hazard vector.}
#'   \item{Q}{Hazard-adjusted operator.}
#'   \item{K_mat}{KRONX generator matrix.}
#'   \item{N_mat}{Fundamental matrix.}
#'   \item{pi_qs}{Quasi-stationary distribution.}
#'   \item{pi_res}{Residence-weight vector.}
#'   \item{loss_threshold}{Empirical left-tail return threshold.}
#'   \item{q_state}{Per-state tail probability.}
#'   \item{bar_q}{Residence-weighted tail probability.}
#'   \item{bar_lambda}{Residence-weighted hazard.}
#'   \item{ruin_bound}{Ruin upper bound over \code{ruin_horizon}.}
#'   \item{tail_alpha}{The \code{tail_alpha} argument used.}
#'   \item{ruin_horizon}{The \code{ruin_horizon} argument used.}
#'   \item{state_summary}{\code{data.frame} summarising all per-state quantities.}
#'   \item{vpath_t}{Integer vector of Viterbi-decoded Student-t state labels.}
#'   \item{output_files}{Character vector of paths to written output files
#'     (\code{NULL} if \code{output_dir} is \code{NULL}).}
#' }
#'
#' @examples
#' \dontrun{
#' res <- run_kronx("IBKR_ES_2Y1h.csv")
#' print(res$ruin_bound)
#'
#' # With a Capital-C column name:
#' res <- run_kronx("mydata.csv", close_col = "Close")
#' }
#'
#' @export
run_kronx <- function(
    file,
    close_col    = "close",
    K            = 3L,
    n_starts     = 5L,
    max_iter     = 200L,
    tol          = 1e-6,
    seed         = 123L,
    epsilon_min  = 0.01,
    c_hazard     = 0.05,
    tail_alpha   = 0.01,
    ruin_horizon = 250L,
    nu_grid      = c(3:30, 40, 60, 100),
    verbose      = TRUE,
    output_dir   = "kronx_output"
) {
  options(stringsAsFactors = FALSE)
  set.seed(seed)

  # ---- 1. Data ingestion ----
  close_px <- read_close_series(file, close_col)
  ret      <- compute_log_returns(close_px)

  cat(sprintf("\nLoaded %d closes and %d log returns from '%s'\n",
              length(close_px), length(ret), file))

  # ---- 2. Fit Gaussian HMM ----
  cat("\nFitting Gaussian HMM...\n")
  gauss_fit <- fit_hmm_em(
    x        = ret,
    K        = K,
    model    = "gaussian",
    n_starts = n_starts,
    max_iter = max_iter,
    tol      = tol,
    nu_grid  = nu_grid,
    verbose  = verbose
  )
  gauss_fit <- reorder_fit_by_scale(gauss_fit)

  # ---- 3. Fit Student-t HMM ----
  cat("\nFitting Student-t HMM...\n")
  t_fit <- fit_hmm_em(
    x        = ret,
    K        = K,
    model    = "student",
    n_starts = n_starts,
    max_iter = max_iter,
    tol      = tol,
    nu_grid  = nu_grid,
    verbose  = verbose
  )
  t_fit <- reorder_fit_by_scale(t_fit)

  # ---- 4. Transition matrices and spell lengths ----
  A_gauss     <- gauss_fit$A
  A_t         <- t_fit$A
  spell_gauss <- expected_spell_lengths(A_gauss)
  spell_t     <- expected_spell_lengths(A_t)
  cond_var_t  <- (t_fit$params$nu / (t_fit$params$nu - 2)) * t_fit$params$sigma^2

  # ---- 5. Viterbi decoding ----
  vpath_t <- viterbi_decode(ret, t_fit)

  # ---- 6. KRONX operator chain construction ----
  epsilon <- hazard_from_nu(t_fit$params$nu, epsilon_min, c_hazard)
  Q       <- build_Q(A_t, epsilon)
  K_mat   <- build_K(Q)
  N_mat   <- fundamental_matrix(K_mat)

  # ---- 7. Quasi-stationary and residence weights ----
  pi_qs  <- quasi_stationary_distribution(Q)
  pi_res <- residence_weight_vector(N_mat, init = pi_qs)

  # ---- 8. Ruin bound ----
  loss_threshold <- as.numeric(
    stats::quantile(ret, probs = tail_alpha, na.rm = TRUE))
  q_state    <- left_tail_state_probs(t_fit, loss_threshold)
  bar_q      <- sum(pi_res * q_state)
  bar_lambda <- sum(pi_res * epsilon)
  ruin_bound <- 1 - exp(-bar_lambda * bar_q * ruin_horizon)

  # ---- 9. State summary table ----
  state_summary <- data.frame(
    state                = seq_len(K),
    mu_gaussian          = gauss_fit$params$mu,
    sigma_gaussian       = gauss_fit$params$sigma,
    spell_gaussian       = spell_gauss,
    mu_student           = t_fit$params$mu,
    sigma_student        = t_fit$params$sigma,
    nu_student           = t_fit$params$nu,
    cond_var_student     = cond_var_t,
    spell_student        = spell_t,
    epsilon              = epsilon,
    q_tail               = q_state,
    pi_quasi_stationary  = pi_qs,
    pi_residence         = pi_res
  )

  # ---- 10. Assemble result ----
  result <- list(
    close_px       = close_px,
    ret            = ret,
    K              = K,
    gauss_fit      = gauss_fit,
    t_fit          = t_fit,
    A_gauss        = A_gauss,
    A_t            = A_t,
    epsilon        = epsilon,
    Q              = Q,
    K_mat          = K_mat,
    N_mat          = N_mat,
    pi_qs          = pi_qs,
    pi_res         = pi_res,
    loss_threshold = loss_threshold,
    q_state        = q_state,
    bar_q          = bar_q,
    bar_lambda     = bar_lambda,
    ruin_bound     = ruin_bound,
    tail_alpha     = tail_alpha,
    ruin_horizon   = ruin_horizon,
    state_summary  = state_summary,
    vpath_t        = vpath_t,
    output_files   = NULL
  )

  # ---- 11. Print summary to console ----
  cat("\n------------------------------------------------------------\n")
  cat("CLOCK OF REGIMES (KRONX) -- SUMMARY\n")
  cat("------------------------------------------------------------\n")
  cat(sprintf("Gaussian HMM log-likelihood : %.10f\n", gauss_fit$logLik))
  cat(sprintf("Student-t HMM log-likelihood: %.10f\n", t_fit$logLik))
  cat(sprintf("Loss threshold (alpha=%.4f): %.8f\n", tail_alpha, loss_threshold))
  cat(sprintf("Residence-weighted qbar     : %.8f\n", bar_q))
  cat(sprintf("Residence-weighted lambda   : %.8f\n", bar_lambda))
  cat(sprintf("Ruin bound (T=%d)           : %.8f\n", ruin_horizon, ruin_bound))
  cat("------------------------------------------------------------\n\n")
  print(state_summary, row.names = FALSE)
  cat("\n")

  # ---- 12. File output ----
  if (!is.null(output_dir)) {
    paths <- write_kronx_outputs(result, output_dir, file)
    result$output_files <- paths
    cat("Output files written to:", output_dir, "\n")
    cat(paste(" -", basename(paths), collapse = "\n"), "\n")
  }

  invisible(result)
}

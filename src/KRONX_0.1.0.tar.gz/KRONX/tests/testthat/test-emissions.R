test_that("emission_logdens_matrix has correct dimensions (Gaussian)", {
  set.seed(1)
  x      <- rnorm(50)
  params <- list(mu = c(-0.01, 0, 0.01), sigma = c(0.01, 0.02, 0.03))
  B      <- KRONX:::emission_logdens_matrix(x, params, "gaussian")
  expect_equal(dim(B), c(50L, 3L))
  expect_true(all(is.finite(B)))
})

test_that("emission_logdens_matrix has correct dimensions (Student-t)", {
  set.seed(2)
  x      <- rnorm(40)
  params <- list(mu = c(0, 0), sigma = c(0.01, 0.02), nu = c(5, 10))
  B      <- KRONX:::emission_logdens_matrix(x, params, "student")
  expect_equal(dim(B), c(40L, 2L))
  expect_true(all(is.finite(B)))
})

test_that("log_dnorm_vec matches dnorm", {
  x   <- c(-1, 0, 1)
  ref <- stats::dnorm(x, mean = 0.1, sd = 0.5, log = TRUE)
  got <- KRONX:::log_dnorm_vec(x, 0.1, 0.5)
  expect_equal(got, ref, tolerance = 1e-12)
})

test_that("log_dt_locscale_vec matches manual calculation", {
  x   <- c(-0.5, 0, 0.5)
  mu  <- 0.1; sigma <- 0.3; nu <- 5
  ref <- stats::dt((x - mu) / sigma, df = nu, log = TRUE) - log(sigma)
  got <- KRONX:::log_dt_locscale_vec(x, mu, sigma, nu)
  expect_equal(got, ref, tolerance = 1e-12)
})

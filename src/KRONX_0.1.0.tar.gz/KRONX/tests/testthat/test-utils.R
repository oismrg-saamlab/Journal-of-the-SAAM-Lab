test_that("safe_normalize returns a proper probability vector", {
  x <- c(1, 2, 3)
  p <- KRONX:::safe_normalize(x)
  expect_equal(sum(p), 1, tolerance = 1e-12)
  expect_true(all(p > 0))
})

test_that("safe_normalize floors near-zero values", {
  x <- c(0, 0, 1)
  p <- KRONX:::safe_normalize(x)
  expect_true(all(p > 0))
  expect_equal(sum(p), 1, tolerance = 1e-12)
})

test_that("row_normalize makes rows sum to one", {
  M <- matrix(c(1, 2, 3, 4), nrow = 2)
  R <- KRONX:::row_normalize(M)
  expect_equal(rowSums(R), c(1, 1), tolerance = 1e-12)
})

test_that("weighted_mean_safe falls back when weights are zero", {
  x <- c(1, 2, 3)
  expect_equal(KRONX:::weighted_mean_safe(x, c(0, 0, 0)), mean(x))
})

test_that("log_sum_exp is numerically stable", {
  x <- c(1000, 1000, 1000)
  expect_equal(KRONX:::log_sum_exp(x), 1000 + log(3), tolerance = 1e-10)
})

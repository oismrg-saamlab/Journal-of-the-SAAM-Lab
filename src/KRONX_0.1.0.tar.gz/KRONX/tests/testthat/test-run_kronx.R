make_csv <- function(col_name = "close", n = 300, seed = 77) {
  set.seed(seed)
  px  <- cumprod(1 + rnorm(n, 0, 0.01)) * 4000
  tmp <- tempfile(fileext = ".csv")
  df  <- setNames(data.frame(px), col_name)
  write.csv(df, tmp, row.names = FALSE)
  tmp
}

test_that("run_kronx completes end-to-end on synthetic 'close' CSV", {
  tmp <- make_csv("close")
  res <- run_kronx(
    file       = tmp,
    K          = 2L,
    n_starts   = 1L,
    max_iter   = 20L,
    nu_grid    = c(5, 10),
    verbose    = FALSE,
    output_dir = tempdir()
  )
  unlink(tmp)
  expect_true(is.finite(res$ruin_bound))
  expect_true(res$ruin_bound > 0 && res$ruin_bound < 1)
  expect_equal(nrow(res$state_summary), 2L)
})

test_that("run_kronx accepts capital-C 'Close' column", {
  tmp <- make_csv("Close")
  res <- run_kronx(
    file       = tmp,
    close_col  = "Close",
    K          = 2L,
    n_starts   = 1L,
    max_iter   = 20L,
    nu_grid    = c(5, 10),
    verbose    = FALSE,
    output_dir = tempdir()
  )
  unlink(tmp)
  expect_true(is.finite(res$ruin_bound))
})

test_that("run_kronx writes expected output files", {
  tmp    <- make_csv("close")
  outdir <- file.path(tempdir(), paste0("kronx_test_", Sys.getpid()))
  res    <- run_kronx(
    file       = tmp,
    K          = 2L,
    n_starts   = 1L,
    max_iter   = 20L,
    nu_grid    = c(5, 10),
    verbose    = FALSE,
    output_dir = outdir
  )
  unlink(tmp)
  expected <- c(
    "kronx_analysis_report.txt",
    "kronx_state_summary.csv",
    "gaussian_transition_matrix.csv",
    "student_t_transition_matrix.csv",
    "kronx_Q_operator.csv",
    "kronx_K_generator.csv",
    "kronx_N_fundamental_matrix.csv",
    "student_t_decoded_states.csv"
  )
  for (f in expected) {
    expect_true(file.exists(file.path(outdir, f)),
                label = paste("missing:", f))
  }
  unlink(outdir, recursive = TRUE)
})

test_that("run_kronx with output_dir = NULL produces no files", {
  tmp <- make_csv("close")
  res <- run_kronx(
    file       = tmp,
    K          = 2L,
    n_starts   = 1L,
    max_iter   = 20L,
    nu_grid    = c(5, 10),
    verbose    = FALSE,
    output_dir = NULL
  )
  unlink(tmp)
  expect_null(res$output_files)
})

test_that("run_kronx state_summary has all required columns", {
  tmp <- make_csv("close")
  res <- run_kronx(
    file       = tmp,
    K          = 2L,
    n_starts   = 1L,
    max_iter   = 20L,
    nu_grid    = c(5, 10),
    verbose    = FALSE,
    output_dir = NULL
  )
  unlink(tmp)
  expected_cols <- c(
    "state", "mu_gaussian", "sigma_gaussian", "spell_gaussian",
    "mu_student", "sigma_student", "nu_student", "cond_var_student",
    "spell_student", "epsilon", "q_tail",
    "pi_quasi_stationary", "pi_residence"
  )
  expect_true(all(expected_cols %in% names(res$state_summary)))
})

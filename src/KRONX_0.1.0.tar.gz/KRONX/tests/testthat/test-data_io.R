test_that("read_close_series reads lowercase 'close' column", {
  tmp <- tempfile(fileext = ".csv")
  write.csv(data.frame(close = c(100, 101, 102, 103, 104,
                                  105, 106, 107, 108, 109, 110)),
            tmp, row.names = FALSE)
  px <- read_close_series(tmp)
  expect_length(px, 11)
  expect_true(all(is.finite(px)))
  unlink(tmp)
})

test_that("read_close_series reads capital 'Close' column", {
  tmp <- tempfile(fileext = ".csv")
  write.csv(data.frame(Close = seq(200, 210, by = 1)),
            tmp, row.names = FALSE)
  px <- read_close_series(tmp, close_col = "Close")
  expect_length(px, 11)
  unlink(tmp)
})

test_that("read_close_series fuzzy-matches any column containing 'close'", {
  tmp <- tempfile(fileext = ".csv")
  write.csv(data.frame(adjClose = seq(50, 65, by = 1)),
            tmp, row.names = FALSE)
  # fuzzy fallback: 'adjClose' contains 'close'
  expect_message(
    px <- read_close_series(tmp, close_col = "close"),
    regexp = "not found"
  )
  expect_true(length(px) >= 10)
  unlink(tmp)
})

test_that("read_close_series errors when file does not exist", {
  expect_error(read_close_series("no_such_file.csv"), "not found")
})

test_that("read_close_series errors when column is missing", {
  tmp <- tempfile(fileext = ".csv")
  write.csv(data.frame(open = 1:15), tmp, row.names = FALSE)
  expect_error(read_close_series(tmp, close_col = "close"), "not found")
  unlink(tmp)
})

test_that("compute_log_returns has length one less than input", {
  px  <- cumsum(c(100, abs(rnorm(20))))
  ret <- compute_log_returns(px)
  expect_length(ret, length(px) - 1L)
  expect_true(all(is.finite(ret)))
})

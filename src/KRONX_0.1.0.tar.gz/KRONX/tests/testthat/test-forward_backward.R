make_simple_fb <- function(T = 30, K = 2, seed = 7) {
  set.seed(seed)
  # sigma matches the unit-normal scale of x so emissions are finite
  x      <- rnorm(T)
  params <- list(mu = c(-0.2, 0.2), sigma = c(0.8, 1.2))
  logB   <- KRONX:::emission_logdens_matrix(x, params, "gaussian")
  A      <- KRONX:::row_normalize(matrix(c(0.9, 0.1, 0.2, 0.8), 2, 2))
  delta  <- c(0.5, 0.5)
  list(logB = logB, A = A, delta = delta)
}

test_that("forward_backward returns finite log-likelihood", {
  fb_in <- make_simple_fb()
  fb    <- KRONX:::forward_backward(fb_in$logB, fb_in$A, fb_in$delta)
  expect_true(is.finite(fb$logLik))
})

test_that("gamma rows sum to one", {
  fb_in <- make_simple_fb()
  fb    <- KRONX:::forward_backward(fb_in$logB, fb_in$A, fb_in$delta)
  rs    <- rowSums(fb$gamma)
  expect_equal(rs, rep(1, nrow(fb$gamma)), tolerance = 1e-8)
})

test_that("xi slices are non-negative and finite", {
  fb_in <- make_simple_fb()
  fb    <- KRONX:::forward_backward(fb_in$logB, fb_in$A, fb_in$delta)
  expect_true(all(is.finite(fb$xi)))
  expect_true(all(fb$xi >= 0))
})

test_that("alpha and beta have correct dimensions", {
  set.seed(42)
  T  <- 25; K <- 3
  x  <- rnorm(T)
  logB  <- matrix(stats::dnorm(
    rep(x, K), mean = rep(c(-0.3, 0, 0.3), each = T),
    sd = 1, log = TRUE), nrow = T, ncol = K)
  A     <- KRONX:::row_normalize(matrix(runif(K * K), K, K))
  delta <- KRONX:::safe_normalize(runif(K))
  fb    <- KRONX:::forward_backward(logB, A, delta)
  expect_equal(dim(fb$alpha), c(T, K))
  expect_equal(dim(fb$beta),  c(T, K))
})

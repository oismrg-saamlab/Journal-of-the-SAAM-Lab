test_that("viterbi_decode returns an integer path of correct length", {
  set.seed(5)
  ret <- rnorm(80)
  fit <- fit_hmm_em(ret, K = 2L, model = "gaussian",
                    n_starts = 1L, max_iter = 20L, verbose = FALSE)
  path <- viterbi_decode(ret, fit)
  expect_length(path, length(ret))
  expect_true(all(path %in% seq_len(fit$K)))
})

test_that("viterbi_decode state labels are within 1..K", {
  set.seed(6)
  ret <- rnorm(60)
  fit <- fit_hmm_em(ret, K = 3L, model = "student",
                    n_starts = 1L, max_iter = 20L, verbose = FALSE,
                    nu_grid = c(5, 10))
  path <- viterbi_decode(ret, fit)
  expect_true(all(path >= 1L & path <= 3L))
})

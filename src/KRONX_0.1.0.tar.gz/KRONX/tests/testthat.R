library(testthat)
library(KRONX)
test_check("KRONX")

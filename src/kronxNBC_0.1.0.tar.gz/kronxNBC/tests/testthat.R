library(testthat)
library(kronxNBC)

test_check("kronxNBC")

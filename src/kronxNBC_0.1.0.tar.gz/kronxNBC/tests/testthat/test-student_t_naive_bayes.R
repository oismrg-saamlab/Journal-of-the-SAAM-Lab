# =============================================================================
# testthat suite — student_t_naive_bayes
# =============================================================================
# Synthetic data: 3 financial-regime classes with heavy-tailed features.
#   Calm  — near-Gaussian returns, low volatility
#   Stress — fat-tailed (t, df=3), high volatility
#   Trend  — shifted mean, moderate tails

set.seed(2024L)

n_per <- 60L
y_raw <- rep(c("Calm", "Stress", "Trend"), each = n_per)
y_fac <- factor(y_raw, levels = c("Calm", "Stress", "Trend"))

X <- rbind(
    cbind(ret = rnorm(n_per, 0.00,  0.5),   vol = rnorm(n_per, 0.10, 0.02),  dd = rnorm(n_per, -0.01, 0.01)),
    cbind(ret = rt(n_per,  df = 3) * 1.5,   vol = rnorm(n_per, 0.40, 0.05),  dd = rnorm(n_per, -0.10, 0.04)),
    cbind(ret = rnorm(n_per, 0.02,  0.6),   vol = rnorm(n_per, 0.20, 0.03),  dd = rnorm(n_per, -0.03, 0.02))
)

# Held-out test set (20 obs, same structure)
X_test <- rbind(
    cbind(ret = rnorm(7L, 0.00, 0.5),  vol = rnorm(7L, 0.10, 0.02),  dd = rnorm(7L, -0.01, 0.01)),
    cbind(ret = rt(7L, df = 3) * 1.5,  vol = rnorm(7L, 0.40, 0.05),  dd = rnorm(7L, -0.10, 0.04)),
    cbind(ret = rnorm(6L, 0.02, 0.6),  vol = rnorm(6L, 0.20, 0.03),  dd = rnorm(6L, -0.03, 0.02))
)

# Fit once; shared across all tests
m <- student_t_naive_bayes(X, y_fac)


# =============================================================================
# 1. Model fitting
# =============================================================================

test_that("student_t_naive_bayes() returns correct S3 class", {
    expect_s3_class(m, "student_t_naive_bayes")
})

test_that("fitted object has required components", {
    expect_named(m, c("data", "levels", "params", "prior", "nu_grid", "call"),
                 ignore.order = TRUE)
})

test_that("levels are correct and ordered", {
    expect_equal(m$levels, c("Calm", "Stress", "Trend"))
})

test_that("param matrices have correct dimensions (K x p)", {
    expect_equal(dim(m$params$mu), c(3L, 3L))
    expect_equal(dim(m$params$sd), c(3L, 3L))
    expect_equal(dim(m$params$nu), c(3L, 3L))
})

test_that("param matrix dimnames match classes and features", {
    expect_equal(rownames(m$params$mu), c("Calm", "Stress", "Trend"))
    expect_equal(colnames(m$params$mu), c("ret", "vol", "dd"))
})

test_that("prior probabilities sum to 1", {
    expect_equal(sum(m$prior), 1, tolerance = 1e-10)
})

test_that("prior probabilities are equal for balanced classes", {
    expect_equal(unname(m$prior), rep(1/3, 3L), tolerance = 1e-10)
})

test_that("all nu values are within nu_grid", {
    expect_true(all(m$params$nu %in% m$nu_grid))
})

test_that("all sd values are strictly positive", {
    expect_true(all(m$params$sd > 0))
})

test_that("nu_grid default covers heavy-tail range", {
    expect_true(min(m$nu_grid) <= 3L)
    expect_true(max(m$nu_grid) >= 60L)
})

test_that("fit rejects non-numeric x", {
    X_bad <- X
    storage.mode(X_bad) <- "character"
    expect_error(student_t_naive_bayes(X_bad, y_fac),
                 regexp = "numeric matrix")
})

test_that("fit rejects x without column names", {
    X_nonames <- unname(X)
    expect_error(student_t_naive_bayes(X_nonames, y_fac),
                 regexp = "column names")
})

test_that("fit rejects nu_grid with values <= 2", {
    expect_error(student_t_naive_bayes(X, y_fac, nu_grid = c(1, 5, 10)),
                 regexp = "> 2")
})

test_that("fit rejects fewer than 2 classes", {
    expect_error(student_t_naive_bayes(X[1:10, ], factor(rep("Calm", 10L))),
                 regexp = "two classes")
})

test_that("fit rejects class with fewer than 2 observations", {
    y_sparse <- factor(c("Calm", "Stress", rep("Trend", n_per * 3L - 2L)),
                       levels = c("Calm", "Stress", "Trend"))
    expect_error(student_t_naive_bayes(X, y_sparse),
                 regexp = "two observations")
})

test_that("custom prior is accepted and normalised", {
    m2 <- student_t_naive_bayes(X, y_fac, prior = c(2, 1, 1))
    expect_equal(sum(m2$prior), 1, tolerance = 1e-10)
    expect_equal(unname(m2$prior[1L]), 0.5, tolerance = 1e-10)
})

test_that("custom prior length mismatch is rejected", {
    expect_error(student_t_naive_bayes(X, y_fac, prior = c(0.5, 0.5)),
                 regexp = "prior")
})

test_that("NA rows in y are silently dropped", {
    y_na <- y_fac
    y_na[1L] <- NA
    expect_no_error(student_t_naive_bayes(X, y_na))
})


# =============================================================================
# 2. predict — type = "class"
# =============================================================================

test_that("predict(type='class') returns a factor", {
    pred <- predict(m, newdata = X_test, type = "class")
    expect_s3_class(pred, "factor")
})

test_that("predict(type='class') factor levels match training levels", {
    pred <- predict(m, newdata = X_test, type = "class")
    expect_equal(levels(pred), c("Calm", "Stress", "Trend"))
})

test_that("predict(type='class') length equals nrow(newdata)", {
    pred <- predict(m, newdata = X_test, type = "class")
    expect_equal(length(pred), nrow(X_test))
})

test_that("predict(type='class') returns all values within known classes", {
    pred <- predict(m, newdata = X_test, type = "class")
    expect_true(all(as.character(pred) %in% c("Calm", "Stress", "Trend")))
})

test_that("predict(type='class') on single row returns length-1 factor", {
    pred1 <- predict(m, newdata = X_test[1L, , drop = FALSE], type = "class")
    expect_s3_class(pred1, "factor")
    expect_equal(length(pred1), 1L)
})

test_that("predict defaults to training data when newdata is NULL", {
    pred_null <- predict(m, type = "class")
    expect_equal(length(pred_null), nrow(X))
})


# =============================================================================
# 3. predict — type = "prob"
# =============================================================================

test_that("predict(type='prob') returns a numeric matrix", {
    prob <- predict(m, newdata = X_test, type = "prob")
    expect_true(is.matrix(prob))
    expect_type(prob, "double")
})

test_that("predict(type='prob') has correct dimensions", {
    prob <- predict(m, newdata = X_test, type = "prob")
    expect_equal(nrow(prob), nrow(X_test))
    expect_equal(ncol(prob), 3L)
})

test_that("predict(type='prob') colnames match class levels", {
    prob <- predict(m, newdata = X_test, type = "prob")
    expect_equal(colnames(prob), c("Calm", "Stress", "Trend"))
})

test_that("predict(type='prob') rows sum to 1", {
    prob <- predict(m, newdata = X_test, type = "prob")
    expect_equal(rowSums(prob), rep(1, nrow(X_test)), tolerance = 1e-6)
})

test_that("predict(type='prob') values are in [0, 1]", {
    prob <- predict(m, newdata = X_test, type = "prob")
    expect_true(all(prob >= 0 & prob <= 1))
})

test_that("predict(type='prob') on single row returns 1-row matrix", {
    prob1 <- predict(m, newdata = X_test[1L, , drop = FALSE], type = "prob")
    expect_true(is.matrix(prob1))
    expect_equal(nrow(prob1), 1L)
    expect_equal(ncol(prob1), 3L)
    expect_equal(rowSums(prob1), 1, tolerance = 1e-6)
})

test_that("MAP class from 'class' agrees with argmax of 'prob'", {
    pred_class <- predict(m, newdata = X_test, type = "class")
    pred_prob  <- predict(m, newdata = X_test, type = "prob")
    argmax_lev <- colnames(pred_prob)[max.col(pred_prob, "first")]
    expect_equal(as.character(pred_class), argmax_lev)
})


# =============================================================================
# 4. tables()
# =============================================================================

test_that("tables() returns a naive_bayes_tables object", {
    tabs <- tables(m)
    expect_s3_class(tabs, "naive_bayes_tables")
})

test_that("tables() returns one element per feature", {
    tabs <- tables(m)
    expect_equal(length(tabs), 3L)
    expect_named(tabs, c("ret", "vol", "dd"))
})

test_that("each table has rows mu, sd, nu", {
    tabs <- tables(m)
    for (nm in names(tabs)) {
        expect_equal(rownames(tabs[[nm]]), c("mu", "sd", "nu"),
                     info = paste("feature:", nm))
    }
})

test_that("each table has columns matching class levels", {
    tabs <- tables(m)
    for (nm in names(tabs)) {
        expect_equal(colnames(tabs[[nm]]), c("Calm", "Stress", "Trend"),
                     info = paste("feature:", nm))
    }
})

test_that("mu row matches fitted params$mu", {
    tabs <- tables(m)
    for (nm in names(tabs)) {
        expect_equal(
            unname(tabs[[nm]]["mu", ]),
            unname(m$params$mu[, nm]),
            tolerance = 1e-10,
            info = paste("feature:", nm)
        )
    }
})

test_that("sd row matches fitted params$sd", {
    tabs <- tables(m)
    for (nm in names(tabs)) {
        expect_equal(
            unname(tabs[[nm]]["sd", ]),
            unname(m$params$sd[, nm]),
            tolerance = 1e-10,
            info = paste("feature:", nm)
        )
    }
})

test_that("nu row matches fitted params$nu", {
    tabs <- tables(m)
    for (nm in names(tabs)) {
        expect_equal(
            unname(tabs[[nm]]["nu", ]),
            unname(m$params$nu[, nm]),
            tolerance = 1e-10,
            info = paste("feature:", nm)
        )
    }
})

test_that("tables(which = integer) subsets correctly", {
    tabs2 <- tables(m, which = 2L)
    expect_equal(length(tabs2), 1L)
    expect_named(tabs2, "vol")
})

test_that("tables(which = character) subsets correctly", {
    tabs_ret <- tables(m, which = "ret")
    expect_equal(length(tabs_ret), 1L)
    expect_named(tabs_ret, "ret")
})

test_that("tables(which = out-of-range integer) errors", {
    expect_error(tables(m, which = 99L), regexp = "out of range")
})

test_that("tables(which = unknown name) errors", {
    expect_error(tables(m, which = "nonexistent"), regexp = "not available")
})

test_that("Stress regime nu is plausibly lower than Calm regime nu for 'ret'", {
    tabs <- tables(m)
    nu_stress <- tabs[["ret"]]["nu", "Stress"]
    nu_calm   <- tabs[["ret"]]["nu", "Calm"]
    # t(df=3) training data should drive nu_stress lower than nu_calm
    # This is a distributional property, not guaranteed on every seed,
    # so we only check both are in the valid grid range.
    expect_true(nu_stress %in% m$nu_grid)
    expect_true(nu_calm   %in% m$nu_grid)
})


# =============================================================================
# 5. coef()
# =============================================================================

test_that("coef() returns a data frame", {
    expect_s3_class(coef(m), "data.frame")
})

test_that("coef() has p rows and 3K columns", {
    cf <- coef(m)
    expect_equal(nrow(cf), 3L)   # p = 3 features
    expect_equal(ncol(cf), 9L)   # 3 classes * 3 params
})

test_that("coef() column names follow <class>:<param> pattern", {
    cf <- coef(m)
    expected <- paste0(rep(c("Calm", "Stress", "Trend"), each = 3L),
                       c(":mu", ":sd", ":nu"))
    expect_equal(colnames(cf), expected)
})

test_that("coef() row names are feature names", {
    cf <- coef(m)
    expect_equal(rownames(cf), c("ret", "vol", "dd"))
})


# =============================================================================
# 6. print() and summary() smoke tests
# =============================================================================

test_that("print() runs without error and returns invisibly", {
    expect_no_error(capture.output(print(m)))
    expect_invisible(print(m))
})

test_that("summary() runs without error and returns invisibly", {
    expect_no_error(capture.output(summary(m)))
    expect_invisible(summary(m))
})

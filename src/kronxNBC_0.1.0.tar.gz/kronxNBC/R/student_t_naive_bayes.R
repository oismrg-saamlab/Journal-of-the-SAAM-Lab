# =============================================================================
# Student-t Naive Bayes — S3 class, constructor, and methods
# =============================================================================

# One-feature MLE via a single IRLS step at each nu candidate.
# Returns list(mu, sd, nu) for the nu that maximises the profile log-likelihood.
#' @importFrom stats sd
#' @noRd
.fit_st_mle_one <- function(x, nu_grid, eps_sd = 1e-8) {
    x <- x[is.finite(x)]
    n <- length(x)
    if (n < 2L)
        return(list(mu = mean(x), sd = eps_sd, nu = nu_grid[1L]))

    best_ll <- -Inf
    best_mu <- mean(x)
    best_sd <- sd(x) + eps_sd
    best_nu <- nu_grid[1L]

    for (nu in nu_grid) {
        mu_hat <- mean(x)
        z2     <- ((x - mu_hat) / (sqrt(mean((x - mu_hat)^2)) + eps_sd))^2
        uw     <- (nu + 1) / (nu + z2)
        mu_hat <- sum(uw * x) / sum(uw)
        sd_hat <- sqrt(mean((x - mu_hat)^2)) + eps_sd

        ll <- sum(stats::dt((x - mu_hat) / sd_hat, df = nu, log = TRUE) - log(sd_hat))
        if (ll > best_ll) {
            best_ll <- ll
            best_mu <- mu_hat
            best_sd <- sd_hat
            best_nu <- nu
        }
    }
    list(mu = best_mu, sd = best_sd, nu = best_nu)
}


# ---- Constructor -------------------------------------------------------------

#' Student-t Naive Bayes Classifier
#'
#' @description
#' Fits a Naive Bayes classifier where the per-class, per-feature likelihood is
#' a scaled Student-t distribution.  The degrees-of-freedom parameter \eqn{\nu}
#' is selected for every (class, feature) pair by a profile log-likelihood grid
#' search over \code{nu_grid}, making the model robust to the fat-tailed returns
#' that characterise financial Stress regimes.
#'
#' @details
#' **Classification rule (MAP)**
#'
#' Under the Naive Bayes conditional-independence assumption the posterior
#' log-odds reduce to the Maximum A Posteriori rule:
#'
#' \deqn{
#'   \hat{k} = \arg\max_{k \in \{1,\dots,K\}} \Bigl[
#'     \log \pi_k +
#'     \sum_{j=1}^{p}
#'       \log f_{t}\!\left(x_j \,\Big|\, \mu_{kj},\, \sigma_{kj},\, \nu_{kj}\right)
#'   \Bigr]
#' }{argmax_k [ log(pi_k) + sum_j log f_t(x_j | mu_kj, sigma_kj, nu_kj) ]}
#'
#' where the scaled Student-t density is
#'
#' \deqn{
#'   f_{t}(x \mid \mu, \sigma, \nu) =
#'     \frac{1}{\sigma}\,
#'     f_{t_\nu}\!\!\left(\frac{x - \mu}{\sigma}\right)
#' }{f_t(x | mu, sigma, nu) = (1/sigma) * dt((x - mu)/sigma, df = nu)}
#'
#' and \eqn{\pi_k} is the prior probability of class \eqn{k}.
#'
#' **Degrees-of-freedom grid search**
#'
#' For each (class \eqn{k}, feature \eqn{j}) pair the algorithm runs one IRLS
#' step at every candidate \eqn{\nu \in} \code{nu_grid} and retains the triplet
#' \eqn{(\hat\mu, \hat\sigma, \hat\nu)} that maximises the profile
#' log-likelihood.  This discrete search avoids the numerical instability of
#' continuous \eqn{\nu} optimisation and is the mechanism that prevents
#' log-likelihood underflow when scoring crisis observations in the Stress
#' regime.
#'
#' @param x A numeric matrix of predictors with named columns.  Each column is
#'   one feature; each row is one observation.
#' @param y A factor, character, or logical vector of class labels with length
#'   equal to \code{nrow(x)}.  Must contain at least two distinct classes and
#'   at least two observations per class.
#' @param prior Optional named numeric vector of prior class probabilities.
#'   Length must equal the number of class levels.  Defaults to empirical class
#'   frequencies.  Supplied values are normalised to sum to one.
#' @param nu_grid Numeric vector of candidate degrees-of-freedom values used by
#'   the profile grid search.  All values must be strictly greater than 2
#'   (finite-variance requirement).  Default: \code{c(3:30, 40, 60, 100)}.
#'   \itemize{
#'     \item Values near 3 capture extreme kurtosis typical of Stress regimes.
#'     \item Values near 30+ approximate Gaussian behaviour for Calm regimes.
#'     \item Including 60 and 100 provides a near-Gaussian safety net without
#'       imposing normality.
#'   }
#' @param ... Additional arguments (currently unused).
#'
#' @return An S3 object of class \code{"student_t_naive_bayes"} with components:
#'   \describe{
#'     \item{\code{data}}{List with elements \code{x} (training matrix) and
#'       \code{y} (training labels).}
#'     \item{\code{levels}}{Character vector of class levels.}
#'     \item{\code{params}}{Named list with \eqn{K \times p} matrices
#'       \code{mu}, \code{sd}, and \code{nu} (\eqn{K} = classes,
#'       \eqn{p} = features).}
#'     \item{\code{prior}}{Named numeric vector of prior probabilities.}
#'     \item{\code{nu_grid}}{The \code{nu_grid} vector used during fitting.}
#'     \item{\code{call}}{The matched call.}
#'   }
#'
#' @seealso \code{\link{predict.student_t_naive_bayes}},
#'   \code{\link{tables.student_t_naive_bayes}},
#'   \code{\link{coef.student_t_naive_bayes}}
#'
#' @examples
#' set.seed(42)
#' n  <- 150
#' y  <- factor(rep(c("Calm", "Stress", "Trend"), each = n / 3))
#' X  <- matrix(
#'   c(rnorm(50, 0, 1), rt(50, df = 4), rnorm(50, 1, 0.5),
#'     rnorm(50, 0, 1), rt(50, df = 4), rnorm(50, 1, 0.5)),
#'   nrow = n, ncol = 2,
#'   dimnames = list(NULL, c("ret", "vol"))
#' )
#' model <- student_t_naive_bayes(X, y)
#' print(model)
#'
#' @export
student_t_naive_bayes <- function(x, y,
                                   prior   = NULL,
                                   nu_grid = c(3:30, 40, 60, 100),
                                   ...) {
    if (!is.factor(y) && !is.character(y) && !is.logical(y))
        stop("student_t_naive_bayes(): y must be a factor, character, or logical vector.",
             call. = FALSE)
    if (!is.factor(y)) y <- factor(y)

    levels <- levels(y)
    nlev   <- nlevels(y)
    vars   <- colnames(x)

    if (!is.matrix(x))
        x <- as.matrix(x)
    if (!is.numeric(x))
        stop("student_t_naive_bayes(): x must be a numeric matrix.", call. = FALSE)
    if (nlev < 2L)
        stop("student_t_naive_bayes(): y must contain at least two classes.", call. = FALSE)
    if (is.null(vars))
        stop("student_t_naive_bayes(): x must have unique column names.\n", call. = FALSE)
    if (length(nu_grid) == 0L || !is.numeric(nu_grid) || any(nu_grid <= 2))
        stop("student_t_naive_bayes(): nu_grid must be numeric with all values > 2.",
             call. = FALSE)

    if (anyNA(y)) {
        na_y_bool <- is.na(y)
        y <- y[!na_y_bool]
        x <- x[!na_y_bool, ]
    }

    y_counts <- stats::setNames(tabulate(y, nbins = nlev), levels)
    if (any(y_counts < 2L))
        stop("student_t_naive_bayes(): each class must have at least two observations.",
             call. = FALSE)

    if (is.null(prior)) {
        prior <- prop.table(y_counts)
    } else {
        if (length(prior) != nlev)
            stop("student_t_naive_bayes(): prior length must equal the number of classes.",
                 call. = FALSE)
        prior <- stats::setNames(prior / sum(prior), levels)
    }

    p    <- ncol(x)
    mu   <- matrix(NA_real_, nrow = nlev, ncol = p, dimnames = list(levels, vars))
    sd_m <- matrix(NA_real_, nrow = nlev, ncol = p, dimnames = list(levels, vars))
    nu_m <- matrix(NA_real_, nrow = nlev, ncol = p, dimnames = list(levels, vars))

    for (k in seq_len(nlev)) {
        lev_k <- levels[k]
        x_k   <- x[which(y == lev_k), , drop = FALSE]
        for (j in seq_len(p)) {
            par        <- .fit_st_mle_one(x_k[, j], nu_grid = nu_grid)
            mu[k, j]   <- par$mu
            sd_m[k, j] <- par$sd
            nu_m[k, j] <- par$nu
        }
    }

    structure(
        list(
            data    = list(x = x, y = y),
            levels  = levels,
            params  = list(mu = mu, sd = sd_m, nu = nu_m),
            prior   = prior,
            nu_grid = nu_grid,
            call    = match.call()
        ),
        class = "student_t_naive_bayes"
    )
}


# ---- predict -----------------------------------------------------------------

#' Predict method for student_t_naive_bayes
#'
#' Computes MAP class assignments or posterior probabilities for new
#' observations using a fitted \code{\link{student_t_naive_bayes}} model.
#'
#' @param object A fitted \code{"student_t_naive_bayes"} object.
#' @param newdata Optional numeric matrix of new observations with the same
#'   named columns as the training matrix.  If \code{NULL} the training data
#'   stored in \code{object} are used.
#' @param type Character string: \code{"class"} (default) returns a factor of
#'   predicted class labels; \code{"prob"} returns a numeric matrix of
#'   posterior probabilities (rows = observations, columns = classes).
#' @param threshold Minimum log-density floor applied after the \code{eps}
#'   check.  Prevents \eqn{-\infty} contributions from absorbing the posterior.
#'   Default: \code{0.001}.
#' @param eps Densities at or below this value are replaced by
#'   \code{threshold}.  Set to \code{0} (default) to use the machine minimum.
#' @param ... Additional arguments (currently unused).
#'
#' @return
#'   \describe{
#'     \item{\code{type = "class"}}{A \code{\link{factor}} of length
#'       \code{nrow(newdata)} with levels matching the training classes.}
#'     \item{\code{type = "prob"}}{A numeric matrix with \code{nrow(newdata)}
#'       rows and one column per class, containing softmax-normalised posterior
#'       probabilities.}
#'   }
#'
#' @seealso \code{\link{student_t_naive_bayes}}
#'
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(100), 50, 2, dimnames = list(NULL, c("f1", "f2")))
#' y <- factor(rep(c("A", "B"), 25))
#' m <- student_t_naive_bayes(X, y)
#' predict(m, type = "class")
#' predict(m, type = "prob")
#'
#' @export
predict.student_t_naive_bayes <- function(object,
                                           newdata   = NULL,
                                           type      = c("class", "prob"),
                                           threshold = 0.001,
                                           eps       = 0,
                                           ...) {
    if (is.null(newdata)) newdata <- object$data$x
    if (!is.matrix(newdata)) newdata <- as.matrix(newdata)

    type      <- match.arg(type)
    lev       <- object$levels
    n_lev     <- length(lev)
    prior     <- object$prior
    mu        <- object$params$mu
    sd        <- object$params$sd
    nu        <- object$params$nu

    features   <- intersect(colnames(newdata), colnames(mu))
    n_features <- length(features)
    n_obs      <- nrow(newdata)

    newdata <- newdata[, features, drop = FALSE]
    mu      <- mu[, features, drop = FALSE]
    sd      <- sd[, features, drop = FALSE]
    nu      <- nu[, features, drop = FALSE]

    sd[sd <= eps]   <- threshold
    eps_log         <- if (eps == 0) log(.Machine$double.xmin) else log(eps)
    threshold_log   <- log(threshold)

    newdata_t <- t(newdata)
    post      <- matrix(nrow = n_obs, ncol = n_lev)

    for (ith_class in seq_len(n_lev)) {
        mu_k <- mu[ith_class, ]
        sd_k <- sd[ith_class, ]
        nu_k <- nu[ith_class, ]

        log_lik <- numeric(n_obs)
        for (j in seq_len(n_features)) {
            z_j  <- (newdata_t[j, ] - mu_k[j]) / sd_k[j]
            ld_j <- stats::dt(z_j, df = nu_k[j], log = TRUE) - log(sd_k[j])
            if (anyNA(ld_j)) ld_j[is.na(ld_j)] <- 0
            ld_j[ld_j <= eps_log] <- threshold_log
            log_lik <- log_lik + ld_j
        }
        post[, ith_class] <- log_lik + log(prior[ith_class])
    }

    if (type == "class") {
        idx <- if (n_obs == 1L) which.max(post) else max.col(post, "first")
        return(factor(lev[idx], levels = lev))
    }

    # type == "prob": stable log-sum-exp softmax
    if (n_obs == 1L) {
        p_mat <- t(as.matrix(vapply(seq_len(n_lev),
            function(i) 1 / sum(exp(post - post[i])), numeric(1L))))
    } else {
        p_mat <- vapply(seq_len(n_lev),
            function(i) 1 / rowSums(exp(post - post[, i])), numeric(n_obs))
    }
    colnames(p_mat) <- lev
    p_mat
}


# ---- print -------------------------------------------------------------------

#' Print method for student_t_naive_bayes
#'
#' Prints a concise summary of the model, including the call, prior
#' probabilities, and the first five parameter tables.
#'
#' @param x A fitted \code{"student_t_naive_bayes"} object.
#' @param ... Additional arguments (currently unused).
#'
#' @return Invisibly returns \code{x}.
#'
#' @seealso \code{\link{student_t_naive_bayes}},
#'   \code{\link{summary.student_t_naive_bayes}}
#'
#' @export
print.student_t_naive_bayes <- function(x, ...) {
    model    <- "Student-t Naive Bayes"
    n_char   <- getOption("width") - 2L
    str_lr   <- paste0(rep("=", floor((n_char - nchar(model)) / 2L)), collapse = "")
    str_full <- paste0(str_lr, " ", model, " ",
                       if (n_char %% 2L != 0L) "=" else "", str_lr)
    l <- paste0(rep("-", nchar(str_full)), collapse = "")

    cat("\n", str_full, "\n\n Call:\n", sep = "")
    print(x$call)
    cat("\n", l, "\n\n A priori probabilities:\n", sep = "")
    print(x$prior)
    cat("\n", l, "\n\n Tables:\n", sep = "")

    tabs    <- tables(x)
    n       <- length(tabs)
    indices <- seq_len(min(5L, n))
    print(tabs[indices])
    if (n > 5L)
        cat("\n\n# ... and", n - 5L,
            if (n - 5L == 1L) "more table\n\n" else "more tables\n\n", l)
    cat("\n\n")
    invisible(x)
}


# ---- summary -----------------------------------------------------------------

#' Summary method for student_t_naive_bayes
#'
#' Prints a high-level summary of a fitted \code{"student_t_naive_bayes"}
#' model: sample size, feature count, \eqn{\nu} grid range, and prior
#' probabilities.
#'
#' @param object A fitted \code{"student_t_naive_bayes"} object.
#' @param ... Additional arguments (currently unused).
#'
#' @return Invisibly returns \code{object}.
#'
#' @seealso \code{\link{student_t_naive_bayes}},
#'   \code{\link{print.student_t_naive_bayes}}
#'
#' @export
summary.student_t_naive_bayes <- function(object, ...) {
    model    <- "Student-t Naive Bayes"
    n_char   <- getOption("width") - 2L
    str_lr   <- paste0(rep("=", floor((n_char - nchar(model)) / 2L)), collapse = "")
    str_full <- paste0(str_lr, " ", model, " ",
                       if (n_char %% 2L != 0L) "=" else "", str_lr)
    l <- paste0(rep("-", nchar(str_full)), collapse = "")

    cat("\n", str_full, "\n\n", sep = "")
    cat("- Call:", deparse(object$call), "\n")
    cat("- Samples:", length(object$data$y), "\n")
    cat("- Features:", ncol(object$params$mu), "\n")
    cat("- nu grid range:", min(object$nu_grid), "to", max(object$nu_grid), "\n")
    cat("- Prior probabilities:\n")
    cat("    -", paste0(names(object$prior), ": ",
                        round(object$prior, 4L), collapse = "\n    - "))
    cat("\n\n", l, "\n", sep = "")
    invisible(object)
}


# ---- plot --------------------------------------------------------------------

#' Plot method for student_t_naive_bayes
#'
#' Draws per-feature Student-t density curves, one curve per class, for
#' a fitted \code{"student_t_naive_bayes"} model.
#'
#' @param x A fitted \code{"student_t_naive_bayes"} object.
#' @param which Integer or character vector selecting which features to plot.
#'   \code{NULL} (default) plots all features.
#' @param ask Logical.  If \code{TRUE} the user is prompted before each plot.
#'   Default: \code{FALSE}.
#' @param legend Logical.  If \code{TRUE} (default) a legend is added to each
#'   plot.
#' @param legend.box Logical.  If \code{TRUE} the legend is drawn with a box.
#'   Default: \code{FALSE}.
#' @param arg.num Named list of graphical parameters (e.g. \code{col},
#'   \code{lty}) applied to the density lines.  Defaults: sequential integer
#'   colours and solid lines.
#' @param prob Character string: \code{"marginal"} (default) scales each
#'   density by the class prior; \code{"conditional"} plots the raw conditional
#'   density.
#' @param ... Additional graphical arguments passed to \code{\link{plot}}.
#'
#' @return Invisibly returns \code{NULL}.
#'
#' @seealso \code{\link{student_t_naive_bayes}}
#'
#' @export
plot.student_t_naive_bayes <- function(x,
                                        which      = NULL,
                                        ask        = FALSE,
                                        legend     = TRUE,
                                        legend.box = FALSE,
                                        arg.num    = list(),
                                        prob       = c("marginal", "conditional"),
                                        ...) {
    prob   <- match.arg(prob)
    levels <- x$levels
    n_lev  <- length(levels)
    mu_mat <- x$params$mu
    sd_mat <- x$params$sd
    nu_mat <- x$params$nu
    prior  <- x$prior
    vars   <- colnames(mu_mat)

    if (!is.null(which)) {
        if (is.numeric(which))        vars <- vars[which]
        else if (is.character(which)) vars <- intersect(vars, which)
    }
    n_vars <- length(vars)
    if (n_vars == 0L)
        stop("plot.student_t_naive_bayes(): no variables to plot.", call. = FALSE)

    if (ask) { op <- par(ask = TRUE); on.exit(par(op)) }

    args <- modifyList(
        list(col = seq_len(n_lev), lty = rep(1L, n_lev)),
        arg.num
    )

    for (var in vars) {
        x_data <- x$data$x[, var]
        rng    <- range(x_data, na.rm = TRUE)
        pad    <- diff(rng) * 0.4
        xs     <- seq(rng[1L] - pad, rng[2L] + pad, length.out = 512L)

        dens_mat <- vapply(levels, function(lev) {
            mu_k <- mu_mat[lev, var]
            sd_k <- sd_mat[lev, var]
            nu_k <- nu_mat[lev, var]
            d_k  <- stats::dt((xs - mu_k) / sd_k, df = nu_k) / sd_k
            if (prob == "marginal") d_k <- d_k * prior[lev]
            d_k
        }, numeric(512L))

        y_lab <- if (prob == "marginal") "Density (marginal)" else "Density (conditional)"

        plot(xs, dens_mat[, 1L], type = "l",
             main = paste0(var, "  (Student-t)"),
             xlab = var, ylab = y_lab,
             ylim = c(0, max(dens_mat, na.rm = TRUE) * 1.05),
             col  = args$col[1L], lty = args$lty[1L], ...)

        if (n_lev > 1L) {
            for (k in 2L:n_lev)
                graphics::lines(xs, dens_mat[, k],
                                col = args$col[k], lty = args$lty[k])
        }

        if (legend)
            graphics::legend("topright", legend = levels,
                             col = args$col[seq_len(n_lev)],
                             lty = args$lty[seq_len(n_lev)],
                             bty = if (legend.box) "o" else "n")
    }
    invisible(NULL)
}


# ---- coef --------------------------------------------------------------------

#' Coefficient extraction for student_t_naive_bayes
#'
#' Returns a data frame of fitted Student-t parameters (\eqn{\mu}, \eqn{\sigma},
#' \eqn{\nu}) organised by feature (rows) and class (column groups).
#'
#' @param object A fitted \code{"student_t_naive_bayes"} object.
#' @param ... Additional arguments (currently unused).
#'
#' @return A data frame with \eqn{p} rows (features) and \eqn{3K} columns,
#'   named \code{<class>:mu}, \code{<class>:sd}, \code{<class>:nu} for each of
#'   the \eqn{K} classes.
#'
#' @seealso \code{\link{student_t_naive_bayes}}
#'
#' @examples
#' set.seed(7)
#' X <- matrix(rnorm(120), 60, 2, dimnames = list(NULL, c("f1", "f2")))
#' y <- factor(rep(c("A", "B", "C"), 20))
#' m <- student_t_naive_bayes(X, y)
#' coef(m)
#'
#' @export
coef.student_t_naive_bayes <- function(object, ...) {
    params    <- object$params
    levels    <- object$levels
    nlev      <- length(levels)

    mu <- t(params$mu)
    sd <- t(params$sd)
    nu <- t(params$nu)

    col_names <- paste0(rep(levels, each = 3L), c(":mu", ":sd", ":nu"))

    out <- do.call(cbind, lapply(seq_len(nlev), function(k) {
        data.frame(mu[, k], sd[, k], nu[, k])
    }))
    colnames(out)  <- col_names
    rownames(out)  <- colnames(params$mu)
    out
}

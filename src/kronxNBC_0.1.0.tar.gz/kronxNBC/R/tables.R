# =============================================================================
# tables() — S3 generic extended for student_t_naive_bayes
# =============================================================================

# Build a naive_bayes_tables list for a student_t_naive_bayes model.
# Each element covers one feature; rows are mu / sd / nu; columns are class
# levels.  Mirrors the structure of get_gaussian_tables() in naivebayes.
#' @noRd
get_tables_st <- function(object) {
    mu   <- object$params$mu   # K x p
    sd   <- object$params$sd
    nu   <- object$params$nu
    vars <- colnames(mu)
    n_tables <- length(vars)

    tabs <- lapply(seq_len(n_tables), function(i) {
        tab <- as.table(rbind(mu[, i], sd[, i], nu[, i]))
        rownames(tab) <- c("mu", "sd", "nu")
        tab
    })
    names(tabs) <- vars
    class(tabs) <- "naive_bayes_tables"
    attr(tabs, "cond_dist") <- stats::setNames(
        rep("Student-t", n_tables), vars
    )
    tabs
}


# ---- Generic -----------------------------------------------------------------

#' Parameter tables for Naive Bayes classifiers
#'
#' S3 generic that returns per-feature parameter tables for a fitted Naive
#' Bayes model.  For \code{"student_t_naive_bayes"} objects each table contains
#' the fitted \eqn{\mu}, \eqn{\sigma}, and \eqn{\nu} parameters.  For all
#' other model classes the call is forwarded to \code{naivebayes::tables()}.
#'
#' @param object A fitted Naive Bayes model.  Supported classes:
#'   \code{"student_t_naive_bayes"} (this package) and any class accepted by
#'   \code{\link[naivebayes]{tables}}.
#' @param which Integer or character vector selecting which feature tables to
#'   return.  \code{NULL} (default) returns all features.
#' @param ... Additional arguments passed to the method.
#'
#' @return A \code{"naive_bayes_tables"} object: a named list with one element
#'   per selected feature.  For \code{"student_t_naive_bayes"} objects each
#'   element is a \code{\link{table}} with rows \code{mu}, \code{sd},
#'   \code{nu} and one column per class level.
#'
#' @seealso \code{\link[naivebayes]{tables}},
#'   \code{\link{student_t_naive_bayes}}
#'
#' @examples
#' set.seed(3)
#' X <- matrix(rnorm(120), 60, 2, dimnames = list(NULL, c("ret", "vol")))
#' y <- factor(rep(c("Calm", "Stress", "Trend"), 20))
#' m <- student_t_naive_bayes(X, y)
#' tables(m)
#' tables(m, which = "ret")
#' tables(m, which = 2L)
#'
#' @export
tables <- function(object, which = NULL, ...) {
    UseMethod("tables")
}


# ---- student_t_naive_bayes method --------------------------------------------

#' @rdname tables
#' @export
tables.student_t_naive_bayes <- function(object, which = NULL, ...) {
    tabs <- get_tables_st(object)

    if (is.null(which))
        return(tabs)

    vars <- names(tabs)
    if (is.numeric(which)) {
        if (any(which > length(vars)))
            stop("tables(): index out of range.", call. = FALSE)
        v <- vars[which]
    } else if (is.character(which)) {
        if (!all(which %in% vars))
            stop("tables(): at least one variable is not available.", call. = FALSE)
        v <- vars[vars %in% which]
    } else {
        stop("tables(): 'which' must be numeric or character.", call. = FALSE)
    }

    res <- tabs[v]
    attr(res, "cond_dist") <- attr(tabs, "cond_dist")[v]
    res
}


# ---- default method ----------------------------------------------------------

#' @rdname tables
#' @export
tables.default <- function(object, which = NULL, ...) {
    naivebayes::tables(object, which = which, ...)
}

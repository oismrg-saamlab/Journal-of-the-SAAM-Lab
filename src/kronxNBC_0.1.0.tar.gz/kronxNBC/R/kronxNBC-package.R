#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom graphics legend lines par
#' @importFrom stats dt setNames
#' @importFrom utils modifyList
## usethis namespace: end
NULL
